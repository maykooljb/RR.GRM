﻿namespace RR.GRM.Models.Configurations
{
    public class FilesLocationConfiguration
    {
        public string MusicContractPath { get; set; } = "";
        public string DistributionPartnerUsagePath { get; set; } = "";
    }
}
