﻿using RR.GRM.Models.Models;
using RR.GRM.Repository;

namespace RR.GRM.Business
{
    public class ContractService : IContractService
    {
        private IMusicContractRepository _musicContractRepository;
        private IDistributionPartnerUsageRepository _distributionPartnerUsageRepository;

        public ContractService(IMusicContractRepository musicContractRepository, IDistributionPartnerUsageRepository distributionPartnerUsageRepository)
        {
            _musicContractRepository = musicContractRepository;
            _distributionPartnerUsageRepository = distributionPartnerUsageRepository;
        }

        public List<MusicContract> GetActiveContracts(string partnerName, DateTime effectiveDate)
        {
            var allowedUsages = _distributionPartnerUsageRepository
                .GetDistributionPartnerUsages()
                .Where(p => p.Partner.Equals(partnerName, StringComparison.OrdinalIgnoreCase))
                .Select(p => p.Usage)
                .ToHashSet();

            return _musicContractRepository
                .GetMusicContracts()
                .Where(c =>
                    c.Usages.Any(u => allowedUsages.Contains(u)) 
                    && c.StartDate <= effectiveDate 
                    && (!c.EndDate.HasValue || c.EndDate.Value >= effectiveDate))
                .ToList();
        }
    }
}
