﻿using RR.GRM.Models.Models;

namespace RR.GRM.Business
{
    public interface IContractService
    {
        List<MusicContract> GetActiveContracts(string partnerName, DateTime effectiveDate);
    }
}