﻿using Moq;
using RR.GRM.Models.Models;
using RR.GRM.Repository;

namespace RR.GRM.Business.Test
{
    [TestClass]
    public sealed class A_ContractServiceTests
    {
        private ContractService _contractService = null!;

        private readonly Mock<IMusicContractRepository> _musicContractRepositoryMock = new();
        private readonly Mock<IDistributionPartnerUsageRepository> _distributionPartnerUsageRepository = new();
        private List<MusicContract> _musicContracts = null!;
        private List<DistributionPartnerUsage> _distributionPartnerUsages = null!;

        [TestInitialize]
        public void TestInit()
        {
            _musicContracts = [
                new MusicContract {
                    Artist = "Tinie Tempah",
                    Title = "Miami 2 Ibiza",
                    Usages = ["digital download"],
                    StartDate = DateTime.Parse("02-01-2012")
                }
            ];
            _musicContractRepositoryMock.Setup(mc => mc.GetMusicContracts()).Returns(_musicContracts);

            _distributionPartnerUsages = [
                new DistributionPartnerUsage { 
                    Partner = "ITunes", 
                    Usage = "digital download" 
                }
            ];

            _distributionPartnerUsageRepository.Setup(dpu => dpu.GetDistributionPartnerUsages()).Returns(_distributionPartnerUsages);
            _contractService = new ContractService(_musicContractRepositoryMock.Object, _distributionPartnerUsageRepository.Object);
        }

        [TestMethod]
        public void FiltersContracts_By_PartnerAndDate()
        {            
            var result = _contractService.GetActiveContracts("ITunes", DateTime.Parse("03-01-2012"));

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual("Miami 2 Ibiza", result[0].Title);
        }
    }
}
