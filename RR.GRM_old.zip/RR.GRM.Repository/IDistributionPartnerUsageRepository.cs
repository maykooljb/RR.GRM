﻿using RR.GRM.Models.Models;

namespace RR.GRM.Repository
{
    public interface IDistributionPartnerUsageRepository
    {
        IList<DistributionPartnerUsage> GetDistributionPartnerUsages();
    }
}