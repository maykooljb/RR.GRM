﻿using Reqnroll;
using RR.GRM.Models.Configurations;
using RR.GRM.Repository.DataSources;
using RR.GRM.Business;
using RR.GRM.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace RR.GRM.Specs.Hooks
{
    [Binding]
    public class ScenarioHooks
    {
        private static ScenarioContext _scenarioContext = null!;

        [BeforeScenario]
        public static void Setup(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;

            var services = new ServiceCollection();
            services.Configure<FilesLocationConfiguration>(_ => new FilesLocationConfiguration
            {
                MusicContractPath = Path.Combine(AppContext.BaseDirectory, "TestData", "MusicContracts.csv"),
                DistributionPartnerUsagePath = Path.Combine(AppContext.BaseDirectory, "TestData", "DistributionPartnerContracts.csv")
            });
            services.AddSingleton<IFileOperations, FileOperations>();
            services.AddSingleton<IMusicContractRepository, MusicContractFileRepository>();
            services.AddSingleton<IDistributionPartnerUsageRepository, DistributionPartnerUsageFileRepository>();
            services.AddSingleton<IContractService, ContractService>();

            var provider = services.BuildServiceProvider();

            _scenarioContext.Set(provider.GetService<IContractService>(), "ContractService");
        }
    }
}