﻿namespace RR.GRM.Models.Models
{
    public class DistributionPartnerUsage
    {
        public string Partner { get; set; } = "";
        public string Usage { get; set; } = "";
    }
}
